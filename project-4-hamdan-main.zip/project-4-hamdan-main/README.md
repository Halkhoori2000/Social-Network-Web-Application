# Social Network Application

hza5211

This is a Social Network web application implemented using Django, Javascript, HTML, and Boostrap. It uses Django for server-side operations and Javascript for interactive client-side actions.

Execute the following command on first use. 
```cli
python manage.py migrate 
```

To run the webserver, execute the following command.
```cli
python manage.py runserver
```