from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import render
from django.urls import reverse
from django.utils import timezone
from django.core.paginator import Paginator
from django.views.defaults import page_not_found, permission_denied, server_error, bad_request
from django.core.exceptions import PermissionDenied
from django.template.defaultfilters import date, linebreaks_filter
from django.conf import settings
from django.db.models import Q

from .models import User, Post, Like, Follow

# Helper functions


def post_to_json(post, user):
    data = {
        'text': post.text,
        'textHtml': linebreaks_filter(post.text),
        'username': post.posted_by.username,
        'id': post.id,
        'modified_at': date(post.modified_at, settings.DATETIME_FORMAT),
        'created_at': date(post.created_at, settings.DATETIME_FORMAT),
        'likes': post.like_set.count(),
        'can_like': not post.like_set.filter(posted_by=user).exists() if user.is_authenticated else False,
        'can_edit': post.posted_by == user,
    }
    return data


def index(request):
    # Get the posts and order by date descending
    posts = Post.objects.all().order_by('-created_at')
    paginator = Paginator([post_to_json(p, request.user) for p in posts], 10)

    page_number = request.GET.get('page')
    context = {'page': paginator.get_page(page_number)}

    return render(request, "network/index.html", context)


def post(request):
    # Check if user is autenticated
    if not request.user.is_authenticated:
        return permission_denied(request, PermissionDenied())

    # Create a new post
    if request.method == "POST":
        # Post
        post = Post(text=request.POST["text"], posted_by=request.user,
                    created_at=timezone.now(), modified_at=timezone.now())
        post.save()

        # Get
        next = request.POST["next"]

        return HttpResponseRedirect(next)

    # Update a post
    return bad_request(request, None)


def update_post(request):
    if request.POST["operation"] == "like":
        try:
            # Post a new like
            # Get the post data
            post = Post.objects.get(id=request.POST['id'])

            # Insert like if not available
            if not post.like_set.filter(posted_by=request.user).exists():
                like = Like(post=post, posted_by=request.user,
                            created_at=timezone.now())
                like.save()

            # Refresh post data
            post.refresh_from_db()

            return JsonResponse(post_to_json(post, request.user))

        except:
            return server_error(request)

    if request.POST["operation"] == "unlike":
        try:
            # Post a new like
            # Get the post data
            post = Post.objects.get(id=request.POST['id'])

            # Insert like if not available
            if post.like_set.filter(posted_by=request.user).exists():
                like = post.like_set.get(posted_by=request.user)
                like.delete()

            # Refresh post data
            post.refresh_from_db()

            return JsonResponse(post_to_json(post, request.user))

        except:
            return server_error(request)

    if request.POST["operation"] == "edit":
        try:
            # Edit text of post
            # Get the post data
            post = Post.objects.get(id=request.POST['id'])

            post.text = request.POST['text']
            post.modified_at = timezone.now()
            post.save(update_fields=['text', 'modified_at'])

            return JsonResponse(post_to_json(post, request.user))

        except:
            return server_error(request)

    return bad_request(request, None)


def like(request):
    data = {"likes": 0, "new_operation": ""}

    if request.method == "POST":
        if request.user.is_authenticated:
            # Get the post
            post = Post.objects.get(id=request.POST["post_id"])

            try:
                like = Like.objects.get(post=post, posted_by=request.user)

                if request.POST["operation"] == "Unlike":
                    # Delete the like object
                    like.delete()
                    data["new_operation"] = "Like"

            except:
                if request.POST["operation"] == "Like":
                    # Create a like object
                    like = Like(post=post, posted_by=request.user,
                                created_at=timezone.now())
                    like.save()
                    data["new_operation"] = "Unlike"

    # Update the number of likes
    post = Post.objects.get(id=request.POST["post_id"])
    data["likes"] = post.like_set.count()
    return JsonResponse(data)


def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "network/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "network/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "network/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "network/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "network/register.html")


def profile_view(request, username):
    try:
        # Get user info
        user = User.objects.get(username=username)
        posts = user.post_set.order_by('-created_at')
        paginator = Paginator([post_to_json(p, request.user)
                              for p in posts], 10)

        page_number = request.GET.get('page')
        context = {'user_data': user,
                   'page': paginator.get_page(page_number),
                   'can_follow': not user.followee.filter(follower=request.user).exists() if request.user.is_authenticated else False
                   }

        # Render
        return render(request, "network/profile.html", context)
    except User.DoesNotExist as ex:
        return page_not_found(request, ex)


def follow(request):
    # Check if user is autenticated
    if not request.user.is_authenticated:
        return permission_denied(request, PermissionDenied())

    # Create a new post
    if request.method == "POST":
        # Check if user already followed
        try:
            user = User.objects.get(id=request.POST['followee'])

            # Can't follow self
            if user != request.user:
                # Check if current user already follows
                if not user.followee.filter(follower=request.user).exists():
                    # Create a new entry
                    follow = Follow(
                        followee=user, follower=request.user, created_at=timezone.now())
                    follow.save()

        except:
            pass

        # Get
        next = request.POST["next"]

        return HttpResponseRedirect(next)

    # Update a post
    return bad_request(request, None)


def unfollow(request):
    # Check if user is autenticated
    if not request.user.is_authenticated:
        return permission_denied(request, PermissionDenied())

    # Create a new post
    if request.method == "POST":
        # Check if user already followed
        try:
            user = User.objects.get(id=request.POST['followee'])

            # Can't follow self
            if user != request.user:
                # Check if current user already follows
                if user.followee.filter(follower=request.user).exists():
                    # Create a new entry
                    follow = user.followee.get(follower=request.user)
                    follow.delete()

        except:
            pass

        # Get
        next = request.POST["next"]

        return HttpResponseRedirect(next)

    # Update a post
    return bad_request(request, None)


def following_view(request):
    if not request.user.is_authenticated:
        return HttpResponseRedirect(reverse("login"))

    if request.user.follow_set.exists():
        # Get the followees
        followees = request.user.follow_set.all()
        post_filt = Q()

        for follow in followees:
            post_filt |= Q(posted_by=follow.followee)

        # Get the posts and order by date descending
        posts = Post.objects.filter(post_filt).order_by('-created_at')
    else:
        posts = []

    paginator = Paginator([post_to_json(p, request.user) for p in posts], 10)

    page_number = request.GET.get('page')
    context = {'page': paginator.get_page(page_number)}

    return render(request, "network/following.html", context)
