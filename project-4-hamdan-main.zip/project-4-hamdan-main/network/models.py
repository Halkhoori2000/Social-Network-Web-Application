from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=255, unique=True)
    email = models.EmailField(unique=True)


class Post(models.Model):
    id = models.AutoField(primary_key=True)
    text = models.TextField()
    posted_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField()
    modified_at = models.DateTimeField()


class Like(models.Model):
    id = models.AutoField(primary_key=True)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    posted_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField()


class Follow(models.Model):
    id = models.AutoField(primary_key=True)
    followee = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='followee')
    follower = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField()
