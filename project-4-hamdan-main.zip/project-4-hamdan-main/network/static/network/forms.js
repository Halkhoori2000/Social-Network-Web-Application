// Helper functions
function show(elem) {
    elem.classList.remove('d-none');
}

function hide(elem) {
    elem.classList.add('d-none');
}

function updatePost(form, post) {
    // Hide edit form
    if (post.can_edit) {
        postFormCancelClickHandler(form);
    }

    // Get elements
    const footerElem = form.querySelector('.blockquote-footer');
    const likeBtn = form.querySelector('.post-like-btn');
    const unlikeBtn = form.querySelector('.post-unlike-btn');
    const quoteElem = form.querySelector('blockquote .quote');

    // Set info
    footerElem.innerText = post.likes == 1 ? '1 Like' : `${post.likes} Likes`;
    footerElem.innerText += `, ${post.modified_at}`;

    // Update like/unlike buttons
    if (post.can_like) {
        show(likeBtn);
        hide(unlikeBtn);
    }
    else {
        show(unlikeBtn);
        hide(likeBtn);
    }

    // Update quote
    quoteElem.innerHTML = post.textHtml;
}

// Post form functions
function postFormSubmitHandler(form) {
    // Perform the request
    fetch(form.action, {
        method: 'POST',
        body: new URLSearchParams(new FormData(form))
    }).then(response => {
        if (response.ok) {
            response.json().then(data => {
                updatePost(form, data);
            });;
        }
    });

    // Stop 
    return false;
}

function postFormLikeClickHandler(form) {
    const opField = form.querySelector('.post-operation-field');

    // Set the operation to like 
    opField.value = 'like';
}

function postFormUnlikeClickHandler(form) {
    const opField = form.querySelector('.post-operation-field');

    // Set the operation to like 
    opField.value = 'unlike';
}

function postFormEditClickHandler(form) {
    const opField = form.querySelector('.post-operation-field');
    const textField = form.querySelector('.post-text-field');
    const quote = form.querySelector('blockquote');
    const editBtn = form.querySelector('.post-edit-btn');
    const cancelBtn = form.querySelector('.post-cancel-btn');
    const saveBtn = form.querySelector('.post-save-btn');

    // Show the save buttton
    show(saveBtn);

    // Hide the edit button
    hide(editBtn);

    // Show the cancel button
    show(cancelBtn);

    // Set the operation to edit 
    opField.value = 'edit';

    // Show the textarea
    show(textField);

    // Hide the quote
    hide(quote);

    // Focus on the text field
    textField.focus();
}

function postFormCancelClickHandler(form) {
    const opField = form.querySelector('.post-operation-field');
    const textField = form.querySelector('.post-text-field');
    const quote = form.querySelector('blockquote');
    const editBtn = form.querySelector('.post-edit-btn');
    const cancelBtn = form.querySelector('.post-cancel-btn');
    const saveBtn = form.querySelector('.post-save-btn');

    // Hide the save button
    hide(saveBtn);

    // Show the edit button
    show(editBtn);

    // Hide the cancel button
    hide(cancelBtn);

    // Set the operation to empty 
    opField.value = '';

    // Hide the textarea
    hide(textField);

    // Show the quote
    show(quote);
}